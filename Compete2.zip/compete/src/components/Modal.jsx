import { useEffect } from "react";
import { CloseIcon } from "./Icons.jsx";

export default function Modal({ title, onClose, children, wide = false }) {
  useEffect(() => {
    const onKey = (e) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-ink/40 p-0 backdrop-blur-sm animate-fade dark:bg-black/60 sm:items-center sm:p-6"
      onMouseDown={(e) => e.target === e.currentTarget && onClose()}
      role="dialog"
      aria-modal="true"
      aria-label={title}
    >
      <div
        className={`card w-full ${wide ? "max-w-2xl" : "max-w-lg"} max-h-[92dvh] overflow-y-auto !rounded-b-none !rounded-t-3xl shadow-modal animate-pop sm:!rounded-3xl`}
      >
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-ink/5 bg-paper/90 px-6 py-4 backdrop-blur dark:border-night-edge dark:bg-night-card/90">
          <h2 className="font-display text-lg font-bold tracking-tight">{title}</h2>
          <button onClick={onClose} className="btn-ghost !p-2" aria-label="Close">
            <CloseIcon size={18} />
          </button>
        </div>
        <div className="p-6">{children}</div>
      </div>
    </div>
  );
}
